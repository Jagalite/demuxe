// SPDX-License-Identifier: Apache-2.0
// Public-API adapters adapted from the retained comparison and qualification harnesses.
import {demuxeLaneOptions} from './remux-evidence.mjs';
const stage = document.querySelector('#stage');
let player, config, overlay, overlayCanvas, overlayTimer, observer;
const observedMedia = [];
const contexts = [], analysers = [], failures = [], events = [], selectionTrace = [], nativeVerificationFailures = [];
let componentTrial, playbackEnded=false;
const originalConnect = AudioNode.prototype.connect;
const OriginalContext = window.AudioContext;
const plain = value => JSON.parse(JSON.stringify(value, (_, v) => typeof v === 'bigint' ? String(v) : v));
const surfaces = tag => [...stage.querySelectorAll(tag), ...[...stage.querySelectorAll('*')].flatMap(e => e.shadowRoot ? [...e.shadowRoot.querySelectorAll(tag)] : [])];
const script = url => new Promise((resolve,reject) => {const s=document.createElement('script'); s.src=url; s.onload=resolve; s.onerror=()=>reject(Error('Missing script '+url)); document.head.append(s);});
addEventListener('error', e => failures.length < 50 && failures.push(e.message));
addEventListener('unhandledrejection', e => failures.length < 50 && failures.push(String(e.reason)));

function observeAudio() {
  const tapped = new WeakSet(), createdMedia = new Set();
  // Streaming wrappers can play a detached video and copy its frames to canvas.
  // Observe those public media elements too; DOM-only discovery misses their audio.
  const createElement=document.createElement;
  document.createElement=function(name,...args) {
    const element=createElement.call(this,name,...args);
    if(['video','audio'].includes(String(name).toLowerCase()))createdMedia.add(element);
    return element;
  };
  function tap(node) {
    if (tapped.has(node)) return;
    tapped.add(node);
    const split = node.context.createChannelSplitter(2);
    originalConnect.call(node, split);
    for (let channel=0; channel<2; channel++) {
      const analyser = node.context.createAnalyser(); analyser.fftSize=8192;
      split.connect(analyser,channel); analysers.push({analyser,channel});
    }
  }
  window.AudioContext = class extends OriginalContext {constructor(...args) {super(...args);contexts.push(this);}};
  AudioNode.prototype.connect = function(destination,...args) {
    if (destination instanceof AudioDestinationNode) tap(this);
    return originalConnect.call(this,destination,...args);
  };
  const seen = new WeakSet();
  observer = setInterval(() => {
    for (const video of new Set([...surfaces('video'),...surfaces('audio'),...createdMedia])) {
      if (seen.has(video)||(!video.currentSrc&&!video.src&&!video.srcObject)) continue;
      seen.add(video);observedMedia.push({element:video,detachedWhenObserved:!video.isConnected});
      for (const type of ['ended','stalled','waiting']) video.addEventListener(type, () => events.push({type,time:video.currentTime}));
      try {
        const context = new OriginalContext(); contexts.push(context);
        const source = context.createMediaElementSource(video);
        source.connect(context.destination); tap(source); context.resume();
      } catch(error) {failures.push('Audio observer: '+error.message);}
    }
  }, 30);
}

async function hostASS() {
  await script('/libass/dist/js/subtitles-octopus.js');
  const canvas = document.createElement('canvas'); canvas.width=960; canvas.height=540;
  overlayCanvas=canvas;
  canvas.style.cssText='position:absolute;inset:0;pointer-events:none'; stage.append(canvas);
  overlay = new SubtitlesOctopus({canvas,subUrl:'/fixtures/captions.ass',fonts:['/fixtures/DejaVuSans.ttf'],
    fallbackFont:'/fixtures/DejaVuSans.ttf',workerUrl:'/libass/dist/js/subtitles-octopus-worker.js',
    onError:error=>failures.push(String(error))});
  overlayTimer=setInterval(()=>overlay.setCurrentTime(snapshot().position),1000/30);
}

export async function start(c) {
  config=c;
  if (c.correctness) observeAudio();
  // A live fixture has a finite authored segment set. Each fresh CPU round
  // needs its own server playlist epoch so later rounds do not reach its end.
  const source = new URL('/fixtures/'+c.file+(c.live?'?case='+encodeURIComponent(c.id)+'&round='+encodeURIComponent(c.round??0):''),location.href).href;
  const subtitle=c.subtitle?new URL('/fixtures/'+c.subtitle,location.href).href:null;
  if (c.player==='video') {
    player=document.createElement('video'); stage.append(player); player.src=source;
    if(subtitle){const track=document.createElement('track');track.src=subtitle;track.kind='subtitles';track.default=true;player.append(track);}
  } else if (c.player==='videojs') {
    await script('/videojs/dist/video.min.js');
    const css=document.createElement('link');css.rel='stylesheet';css.href='/videojs/dist/video-js.min.css';document.head.append(css);
    const element=document.createElement('video');element.className='video-js';stage.append(element);
    player=videojs(element,{controls:false,width:960,height:540,preload:'auto'});
    player.on('error',()=>failures.push(JSON.stringify(player.error())));
    const extension=c.file.split('.').at(-1);
    const types={mp4:'video/mp4',m4a:'audio/mp4',mkv:'video/x-matroska',webm:'video/webm',ts:'video/mp2t',m3u8:'application/x-mpegURL',mpd:'application/dash+xml',ogg:'audio/ogg',opus:'audio/ogg',wav:'audio/wav',mp3:'audio/mpeg',flac:'audio/flac',aac:'audio/aac',mov:'video/quicktime',avi:'video/x-msvideo'};
    player.src({src:source,type:types[extension]??'application/octet-stream'});
    if(subtitle)player.addRemoteTextTrack({src:subtitle,kind:'subtitles',default:true},false);
  } else if (c.player==='demuxe') {
    let extracted;
    const options=c.forceRemux?{nativeRemux:'always'}:{};
    if(c.componentTrial) {
      const trial=await import('./component-trials.mjs');
      componentTrial={kind:c.componentTrial,scope:'LAB ONLY; explicit component substitution'};
      if(c.componentTrial==='subtitles') {
        options.experimentalNativeASS=true;
        if(c.embeddedSubtitle){const began=performance.now();extracted=await trial.extractCaptions(source);componentTrial.extraction={wallMs:performance.now()-began,bytes:extracted.readBytes,format:extracted.format,cues:extracted.cues};}
      } else if(c.componentTrial==='dash')await trial.installDASHTrial();
      else if(c.componentTrial==='audio'){options.experimentalAudioAdaptation='flac';options.nativeRemux='always';}
    }
    const entry=c.demuxePackage?.entry??'/demuxe/web/generated/index.js';
    const assetBase=c.demuxePackage?.assetBase??'/demuxe/';
    const nativePlayerEntry=c.demuxePackage?.nativePlayerEntry??'/demuxe/web/generated/internal/native-player.js';
    for(const value of [entry,assetBase,nativePlayerEntry])if(typeof value!=='string'||!value.startsWith('/demuxe/')||value.includes('..')||value.includes('?')||value.includes('#'))throw Error('Invalid pinned Demuxe package path');
    const {Player}=await import(entry);
    if(c.correctness) {
      const {NativePlayer}=await import(nativePlayerEntry);
      const verify=NativePlayer.prototype.verifyOutput;
      NativePlayer.prototype.verifyOutput=async function(...args) {
        try {return await verify.apply(this,args);}
        catch(error) {
          nativeVerificationFailures.push(plain({error:String(error),diagnostics:this.diagnostics}));
          throw error;
        }
      };
    }
    player=new Player(stage,{assetBase,width:960,height:540,...options,...demuxeLaneOptions(c.lane)});
    if(c.componentTrial)window.componentPlayer=player;
    if(c.correctness)player.addEventListener('selectionchange',event=>{if(selectionTrace.length<100)selectionTrace.push(plain(event.detail));});
    await player.ready; await player.open(c.streamFormat?{url:source,format:c.streamFormat,streaming:{live:!!c.live,...c.streaming}}:source);
    if(c.selectAudioCodec)await selectAudioCodec(c.selectAudioCodec);
    if(extracted){for(const font of extracted.fonts)await player.addFont(new File([font.bytes],font.name));await player.addSubtitle(new File([extracted.text],'extracted.'+extracted.format));}
    if(!extracted&&c.embeddedSubtitle&&player.state.subtitleTracks.length)await player.selectSubtitleTrack(player.state.subtitleTracks[0].id);
    if(subtitle&&!c.subtitleIntegration)await player.addSubtitle(new File([await(await fetch(subtitle)).arrayBuffer()],c.subtitle.split('/').at(-1)));
    if (c.subtitleIntegration==='built-in') {
      await player.addFont(new File([await(await fetch('/fixtures/DejaVuSans.ttf')).arrayBuffer()],'DejaVuSans.ttf'));
      await player.addSubtitle(new File([await(await fetch('/fixtures/captions.ass')).arrayBuffer()],'captions.ass'));
    }
  } else if (c.player==='movi') {
    await import(c.lane==='native-first'?'/packages/movi/package/dist/element.slim.js':'/packages/movi/package/dist/element.js');
    player=document.createElement('movi-player'); player.style.cssText='display:block;width:960px;height:540px';
    player.setAttribute('nohotkeys',''); player.setAttribute('volume','1');player.setAttribute('autoplay','');
    if(c.lane==='native-first') player.setAttribute('engine','native wasm');
    if(c.lane==='shaka-first') player.setAttribute('engine','shaka dashjs hlsjs wasm native');
    if(c.subtitleIntegration==='built-in') {
      const track=document.createElement('track'); track.src='/fixtures/captions.ass';track.kind='subtitles';track.setAttribute('srclang','en');track.label='Marked subtitle';track.default=true;track.setAttribute('data-format','ass');player.append(track);
    }
    if(subtitle&&!c.subtitleIntegration){const track=document.createElement('track');track.src=subtitle;track.kind='subtitles';track.setAttribute('srclang','en');track.label='Marked subtitle';track.default=true;player.append(track);}
    // Movi parses child tracks when connected; add them before attaching the element.
    stage.append(player);
    player.src=source;
  } else if (c.player==='libmedia') {
    await script('/libmedia/dist/cheap-polyfill.js');
    window.CHEAP_POLYFILL_URL=new URL('/libmedia/dist/cheap-polyfill.js',location.href).href;
    await script('/packages/libmedia/package/dist/umd/avplayer.js');
    AVPlayer.setLogLevel(3);
    player=new AVPlayer({container:stage,wasmBaseUrl:'/libmedia/dist',...(c.lane==='webcodecs-off'?{enableWebCodecs:false}:{}),...(['prefer-mse','live-mse'].includes(c.lane)?{checkUseMSE:()=>true}:{})});
    player.on('ended',()=>{playbackEnded=true;events.push({type:'ended',time:Number(player.currentTime)/1000});});
    player.on('seeking',()=>{playbackEnded=false;});
    player.on('played',()=>{playbackEnded=false;});
    const loadOptions=subtitle&&!c.subtitleIntegration?{externalSubtitles:[{source:subtitle,title:'Marked subtitle',lang:'en'}]}:c.subtitleIntegration==='built-in'?{externalSubtitles:[{source:new URL('/fixtures/captions.ass',location.href).href,title:'ASS',lang:'en'}]}:{};
    if(['live','live-mse'].includes(c.lane))loadOptions.isLive=true;
    let input=source;
    if(c.lane==='file-input') {
      const response=await fetch(source);if(!response.ok)throw Error('File-input fetch failed: '+response.status);
      input=new File([await response.arrayBuffer()],c.file.split('/').at(-1));
    }
    await player.load(input,loadOptions);
    player.setVolume(1);
  } else throw Error('Unknown player');
  if (config.subtitleIntegration==='host-libass') await hostASS();
  await player.play();
  return snapshot();
}

export function snapshot() {
  const video=surfaces('video').find(v=>v.currentSrc && v.videoWidth);
  let state={};
  if (player) {
    if(config.player==='demuxe') state={position:player.state.currentTime,duration:player.state.duration,paused:player.state.paused,
      route:player.diagnostics?.plan?.id ?? player.state.activeMode,diagnostics:player.diagnostics,
      audioTracks:player.state.audioTracks,selectedAudioTrack:player.state.audioTracks.find(t=>t.selected)??null,
      selectionTrace,nativeVerificationFailures,componentTrial,mediaTracks:player.properties.get('track-list'),audioParams:player.properties.get('audio-params')};
    else if(config.player==='videojs') state={position:player.currentTime(),duration:player.duration(),paused:player.paused(),ended:player.ended(),route:video?.currentSrc.startsWith('blob:')?'mse':'native-direct',version:videojs.VERSION};
    else if(config.player==='libmedia') state={position:Number(player.currentTime)/1000,duration:Number(player.getDuration())/1000,
      route:player.isMSE()?'mse':'custom',ended:playbackEnded,stats:player.getStats()};
    else state={position:player.currentTime,duration:player.duration,paused:player.paused,route:(video||(config.audio!==false&&surfaces('video').some(v=>v.currentSrc&&v.readyState>=2))||surfaces('audio').some(v=>v.currentSrc))?'native-direct':'custom'};
  }
  if(config.player==='movi'&&video&&config.lane==='shaka-first')state.route='video-surface';
  if(config.player==='movi'&&!video&&typeof player?.getVideoPlaybackQuality==='function')state.renderQuality=player.getVideoPlaybackQuality();
  const audio=analysers.map(({analyser,channel})=>{
    const wave=new Float32Array(analyser.fftSize),bins=new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatTimeDomainData(wave);analyser.getFloatFrequencyData(bins);
    let bin=0;for(let i=1;i<bins.length;i++)if(bins[i]>bins[bin])bin=i;
    return {channel,rms:Math.sqrt(wave.reduce((n,x)=>n+x*x,0)/wave.length),hz:bin*analyser.context.sampleRate/analyser.fftSize};
  });
  return plain({...state,environment:{crossOriginIsolated:globalThis.crossOriginIsolated,sharedArrayBuffer:typeof SharedArrayBuffer,jspiSuspending:typeof WebAssembly.Suspending,jspiPromising:typeof WebAssembly.promising},audio,observedMedia:observedMedia.map(({element,detachedWhenObserved})=>({detachedWhenObserved,connected:element.isConnected,source:element.currentSrc,time:element.currentTime,paused:element.paused,muted:element.muted,volume:element.volume})),errors:failures,events,visible:document.visibilityState==='visible',focused:document.hasFocus(),
    video:video?{source:video.currentSrc,time:video.currentTime,ended:video.ended,paused:video.paused,total:video.getVideoPlaybackQuality().totalVideoFrames,dropped:video.getVideoPlaybackQuality().droppedVideoFrames}:null});
}
export async function subtitles() {
  if(config.player==='demuxe') {
    const tracks=player.state.subtitleTracks;
    if(tracks.length)await player.selectSubtitleTrack((config.componentTrial==='subtitles'?tracks.at(-1):tracks[0]).id);
    return {tracks:plain(tracks)};
  }
  if(config.player==='libmedia') {
    const tracks=player.getStreams().filter(t=>t.mediaType==='subtitle'||t.codecparProxy?.codecType===3);
    if(tracks.length&&player.getSelectedSubtitleStreamId()!==tracks[0].id)await player.selectSubtitle(tracks[0].id);
    // play() already enables subtitles; resetting an active renderer here discards its current cue.
    return {tracks:tracks.map(t=>({id:t.id,mediaType:t.mediaType})),selected:player.getSelectedSubtitleStreamId()};
  }
  if(config.player==='movi') {
    const languages=player.getSubtitleLangs?.()??[];
    if(languages.length) {
      if(!languages[0].active)await player.selectSubtitleLang(languages[0].lang);
      return {method:'public-language-api',tracks:plain(player.getSubtitleLangs())};
    }
    // Embedded tracks are not mirrored by Movi's HTML textTracks facade.
    // Use the exposed subtitle menu, as a user would, rather than private player internals.
    const root=player.shadowRoot,button=root?.querySelector('.movi-subtitle-track-btn');
    button?.click();
    const items=[...(root?.querySelectorAll('.movi-subtitle-track-item[data-track-id]')??[])].filter(e=>e.dataset.trackId!=='null');
    const selected=items[0];
    if(selected&&!selected.classList.contains('movi-subtitle-track-active'))selected.click();
    if(selected)for(let attempt=0;attempt<20;attempt++) {
      const active=root.querySelector('.movi-subtitle-track-item.movi-subtitle-track-active');
      if(active?.dataset.trackId===selected.dataset.trackId)break;
      await new Promise(resolve=>setTimeout(resolve,50));
    }
    const selection={method:'subtitle-menu',tracks:items.map(e=>({id:e.dataset.trackId,label:e.textContent.trim()})),
      selected:root?.querySelector('.movi-subtitle-track-item.movi-subtitle-track-active')?.dataset.trackId??null};
    if(root?.querySelector('.movi-subtitle-track-menu')?.classList.contains('is-open'))button?.click();
    return selection;
  }
  const tracks=config.player==='videojs'?player.textTracks():player.textTracks;
  if(tracks?.length)tracks[0].mode='showing';
  return {tracks:Array.from(tracks??[]).map(t=>({id:t.id,kind:t.kind,mode:t.mode}))};
}
export async function seek(target) {
  if(config.player==='demuxe') await player.seek(target);
  else if(config.player==='videojs') player.currentTime(target);
  else if(config.player==='libmedia') await player.seek(BigInt(Math.round(target*1000)));
  else player.currentTime=target;
}
export async function pause() {await player.pause();}
export async function resume() {await player.play();}
export async function rate(value) {
  if(['demuxe','libmedia'].includes(config.player)) await player.setPlaybackRate(value);
  else if(config.player==='videojs') player.playbackRate(value);
  else player.playbackRate=value;
}
const codecKey=value=>String(value??'').toLowerCase().replace(/[^a-z0-9]/g,'');
export async function selectAudioCodec(codec) {
  if(config.player!=='demuxe')throw Error('Public audio codec selection is available only for Demuxe in this harness');
  const key=codecKey(codec),tracks=player.state.audioTracks??[];
  const track=tracks.find(t=>codecKey(t.codec)===key);
  if(!track)throw Error(`Audio codec ${codec} not found in public track list: ${JSON.stringify(tracks)}`);
  await player.selectAudioTrack(track.id);
  const deadline=performance.now()+3000;
  let selected=player.state.audioTracks.find(t=>t.selected)??null;
  while((!selected||codecKey(selected.codec)!==key)&&performance.now()<deadline){
    await new Promise(resolve=>setTimeout(resolve,25));
    selected=player.state.audioTracks.find(t=>t.selected)??null;
  }
  if(!selected||codecKey(selected.codec)!==key)throw Error(`Audio codec selection did not settle: ${codec}`);
  return plain({requestedCodec:codec,track,selected,route:player.diagnostics?.plan?.id??player.state.activeMode});
}
export async function stop() {
  clearInterval(observer); clearInterval(overlayTimer); overlay?.dispose();overlayCanvas?.remove();
  if(player) {
    if(config.player==='video') {player.pause();player.removeAttribute('src');player.load();player.remove();}
    else if(config.player==='videojs') player.dispose();
    else if(config.player==='movi') {player.pause();player.remove();}
    else await player.destroy();
    if(config.player==='libmedia') await AVPlayer.stopPipelines();
  }
  for(const context of contexts) if(context.state!=='closed') await context.close();
  // Host-owned overlay is removed by its host; player-owned surfaces are measured first.
  const remaining=surfaces('video').length+surfaces('canvas').length+stage.querySelectorAll('movi-player').length;
  return {remainingSurfaces:remaining,contexts:contexts.map(c=>c.state)};
}
window.api={start,snapshot,seek,pause,resume,rate,stop,subtitles,selectAudioCodec};
