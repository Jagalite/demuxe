#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Prepare an immutable comparison input snapshot; never build into the live player."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import urllib.request

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1048576), b''):
            h.update(part)
    return h.hexdigest()


def fetch(url, target, expected, cached=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    if cached and cached.is_file() and sha(cached) == expected:
        shutil.copyfile(cached, target)
    else:
        with urllib.request.urlopen(url, timeout=90) as response, target.open('wb') as output:
            shutil.copyfileobj(response, output)
    if sha(target) != expected:
        raise ValueError('Dependency hash mismatch: ' + str(target))


def extract(archive, target):
    with tarfile.open(archive) as bundle:
        for member in bundle.getmembers():
            relative = Path(member.name)
            if relative.is_absolute() or '..' in relative.parts or relative.parts[0] != 'package':
                raise ValueError('Unsafe package member: ' + member.name)
            if not (member.isfile() or member.isdir()):
                raise ValueError('Package links/special files are not accepted: ' + member.name)
        bundle.extractall(target, filter='data')


def preserve_specialist_contracts(catalogue, specialist):
    for key, entry in specialist.items():
        if key not in catalogue:
            continue
        if catalogue[key].get('file') != entry['file']:
            # A shared key can name different ordinary and specialist fixtures.
            # The specialist catalogue remains separate and is hash checked.
            continue
        for field in ('markedAudio', 'markedVideo'):
            # Legacy metadata is unknown, never implicit marker qualification.
            catalogue[key][field] = entry.get(field, False)


def prepare(args):
    if args.duration < 12:
        raise ValueError('Fixture duration must be at least 12 seconds')
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    lab = Path(args.lab).resolve() if args.lab else None
    commands = []
    preparation = out / 'preparation'
    preparation.mkdir()
    for name in ['setup.py','expand.py','bitmap.py','planned.json']:
        shutil.copyfile(HERE / name, preparation / name)

    def run(command):
        result = subprocess.run(command, cwd=REPO, capture_output=True, text=True)
        commands.append({'argv': command, 'cwd': str(REPO), 'exit': result.returncode,
                         'stdout': result.stdout, 'stderr': result.stderr})
        (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode:
            raise ValueError('Setup command failed; inspect commands.json: ' + command[0])
        return result.stdout

    lock = json.loads((HERE / 'assets.lock.json').read_text())
    for entry in lock['packages']:
        archive = out / 'downloads' / (entry['name'] + '.tgz')
        fetch(entry['url'], archive, entry['sha256'], lab / entry['lab_path'] if lab else None)
        extract(archive, out / 'packages' / entry['name'])
    downloads = []
    for entry in lock['runtime']['files']:
        url = f'https://raw.githubusercontent.com/zhaohappy/libmedia/{lock["runtime"]["commit"]}/{entry["path"]}'
        downloads.append((url, out / 'libmedia' / entry['path'], entry['sha256'], lab / entry['lab_path'] if lab else None))
    for entry in lock['libass']['files']:
        url = f'https://unpkg.com/libass-wasm@{lock["libass"]["version"]}/{entry["path"]}'
        downloads.append((url, out / 'libass' / entry['path'], entry['sha256'], lab / entry['lab_path'] if lab else None))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(lambda values: fetch(*values), downloads))

    # Freeze source and compile current TS to the snapshot, not web/generated in the checkout.
    run(['node', 'scripts/copy-shaka-assets.mjs'])
    shaka = json.loads((REPO / 'third_party/shaka-player.json').read_text())
    source_paths = (sorted((REPO / 'src').rglob('*.ts')) + sorted((REPO / 'web').glob('*.js')) +
                    [REPO / name for name in shaka['files']] +
                    [REPO / name for name in ['third_party/shaka-player.json', 'package-lock.json', 'scripts/copy-shaka-assets.mjs']])
    before = {str(p.relative_to(REPO)): sha(p) for p in source_paths}
    player = out / 'demuxe'
    (player / 'web').mkdir(parents=True)
    for path in (REPO / 'web').glob('*.js'):
        shutil.copyfile(path, player / 'web' / path.name)
    # These runtime imports sit below web/*.js. Snapshot the committed revision
    # so unrelated local presenter experiments cannot enter release evidence.
    for name in subprocess.check_output(['git', 'ls-files', 'web/webgpu'], cwd=REPO, text=True).splitlines():
        target = player / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=REPO))
    for name in shaka['files']:
        target = player / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO / name, target)
    run(['node', 'node_modules/typescript/bin/tsc', '--project', 'tsconfig.json', '--outDir', str(player / 'web/generated')])
    engines = {}
    for name in ['engine-remux', 'engine-hybrid', 'engine-selective', 'engine-software-full', 'engine-software-yuv', 'engine-subtitles', 'engine-adaptation']:
        source = REPO / 'web' / name
        engines[name] = source.is_dir()
        if source.is_dir():
            shutil.copytree(source, player / 'web' / name)
    optional_archive_sha = None
    if args.optional_archive:
        optional_archive = Path(args.optional_archive).resolve()
        optional_archive_sha = sha(optional_archive)
        with tarfile.open(optional_archive) as bundle:
            package = json.load(bundle.extractfile('package/release-manifest.json'))
            for folder, stem in [('engine-adaptation', 'remux')]:
                for filename in [stem + '.mjs', stem + '.wasm', 'manifest.json']:
                    name = f'web/{folder}/{filename}'
                    entry = package['files'].get(name)
                    if not entry:
                        raise ValueError('Optional archive is missing ' + name)
                    data = bundle.extractfile('package/' + name).read()
                    if hashlib.sha256(data).hexdigest() != entry['sha256']:
                        raise ValueError('Optional archive asset hash mismatch: ' + name)
                    target = player / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(data)
                engines[folder] = True
    for name in ['LICENSE', 'LICENSES', 'third_party', 'docs/LICENSING.md', 'docs/MEDIA-NOTICES.md', 'fixtures/FONT-LICENSE.txt']:
        source, target = REPO / name, player / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target) if source.is_dir() else shutil.copyfile(source, target)
    (player / 'fixtures').mkdir(exist_ok=True)
    shutil.copyfile(REPO / 'fixtures/DejaVuSans.ttf', player / 'fixtures/DejaVuSans.ttf')
    after = {str(p.relative_to(REPO)): sha(p) for p in source_paths}
    if before != after:
        raise ValueError('Player source changed during preparation; discard no files, prepare a new snapshot.')
    fixture_parent = None
    if args.fixtures_from:
        parent = Path(args.fixtures_from).resolve()
        parent_manifest = json.loads((parent / 'manifest.json').read_text())
        if parent_manifest['fixture']['duration'] != args.duration:
            raise ValueError('Reused fixture duration must match --duration')
        entries = {name: entry for name, entry in parent_manifest['files'].items() if name.startswith('fixtures/')}
        actual = {str(p.relative_to(parent)) for p in (parent / 'fixtures').rglob('*') if p.is_file()}
        if set(entries) != actual:
            raise ValueError('Reused fixture file inventory mismatch')
        for name, entry in entries.items():
            if sha(parent / name) != entry['sha256']:
                raise ValueError('Reused fixture hash mismatch: ' + name)
        shutil.copytree(parent / 'fixtures', out / 'fixtures')
        shutil.copyfile(parent / 'manifest.json', preparation / 'fixture-parent-manifest.json')
        shutil.copyfile(parent / 'commands.json', preparation / 'fixture-parent-commands.json')
        if (parent / 'preparation').is_dir():
            shutil.copytree(parent / 'preparation', preparation / 'fixture-origin')
        fixture_parent = {'snapshot': str(parent), 'manifest_sha256': sha(parent / 'manifest.json')}
    else:
        fixtures = out / 'fixtures'
        fixtures.mkdir()
        shutil.copyfile(REPO / 'fixtures/DejaVuSans.ttf', fixtures / 'DejaVuSans.ttf')
        shutil.copyfile(REPO / 'fixtures/FONT-LICENSE.txt', fixtures / 'FONT-LICENSE.txt')
        (fixtures / 'NOTICES.md').write_text('Synthetic marked video and channel tones generated by tests/head-to-head/setup.py. No movie content. Original fixture material: CC-BY-4.0, Demuxe contributors. Font retains FONT-LICENSE.txt.\n')
        video = (f"nullsrc=s=320x180:r=30:d={args.duration},"
                 "geq=lum='if(between(Y,70,100)*between(X,mod(T*40,240),mod(T*40,240)+40),235,16)':cb=128:cr=128,"
                 "drawbox=x=0:y=0:w=320:h=40:color=red:t=fill:enable='lt(t,4)',"
                 "drawbox=x=0:y=0:w=320:h=40:color=blue:t=fill:enable='gte(t,4)*lt(t,8)',"
                 "drawbox=x=0:y=0:w=320:h=40:color=green:t=fill:enable='gte(t,8)'")
        run(['ffmpeg', '-nostdin', '-v', 'error', '-f', 'lavfi', '-i', video,
             '-f', 'lavfi', '-i', f'aevalsrc=0.15*sin(2*PI*440*t)|0.15*sin(2*PI*880*t):s=48000:d={args.duration}',
             '-map', '0:v', '-map', '1:a', '-c:v', 'libx264', '-threads', '1', '-pix_fmt', 'yuv420p',
             '-preset', 'fast', '-g', '30', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', str(fixtures / 'aac.mp4')])
        run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(fixtures / 'aac.mp4'), '-map', '0', '-c', 'copy', str(fixtures / 'aac.mkv')])
        run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(fixtures / 'aac.mp4'), '-map', '0', '-c:v', 'copy', '-c:a', 'pcm_s24le', str(fixtures / 'pcm.mkv')])
        (fixtures / 'captions.ass').write_text('''[Script Info]
    ScriptType: v4.00+
    PlayResX: 320
    PlayResY: 180
    [V4+ Styles]
    Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
    Style: Default,DejaVu Sans,20,&H00FF00FF,&H00FF00FF,&H00FF00FF,&H00FF00FF,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
    [Events]
    Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
    Dialogue: 0,0:00:00.50,0:00:11.80,Default,,0,0,0,,{\\an7\\pos(220,130)\\p1}m 0 0 l 70 0 70 30 0 30
    ''')
        caption = fixtures / 'captions.ass'
        end = args.duration - .2
        caption.write_text(caption.read_text().replace('0:00:11.80', f'0:{int(end // 60):02d}:{end % 60:05.2f}'))
        for name in ['aac.mp4', 'aac.mkv', 'pcm.mkv']:
            metadata = run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(fixtures / name)])
            (fixtures / (name + '.probe.json')).write_text(metadata)
            # Host packet hashes establish the copy relation, not browser decoder correctness.
            proof = run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(fixtures / name), '-map', '0:v:0', '-c', 'copy', '-f', 'hash', '-hash', 'sha256', '-'])
            (fixtures / (name + '.video-packets.sha256')).write_text(proof)
        proofs = {(fixtures / (name + '.video-packets.sha256')).read_text() for name in ['aac.mp4', 'aac.mkv', 'pcm.mkv']}
        if len(proofs) != 1:
            raise ValueError('Fixture video packet identity mismatch')
        if args.expanded:
            import sys
            sys.path.insert(0, str(preparation))
            from expand import generate
            generate(fixtures, run, args.duration)
    specialist_parent = None
    if args.specialist_from:
        parent = Path(args.specialist_from).resolve()
        source = parent / 'specialist.json'
        specialist = json.loads(source.read_text())
        for key, entry in specialist.items():
            candidate = (out / 'fixtures' / entry['file']).resolve()
            if not candidate.is_relative_to((out / 'fixtures').resolve()) or not candidate.is_file():
                raise ValueError('Specialist fixture missing: ' + key)
            if sha(candidate) != entry['sha256'] or sha(parent / 'fixtures' / entry['file']) != entry['sha256']:
                raise ValueError('Specialist fixture hash mismatch: ' + key)
        shutil.copyfile(source, out / 'specialist.json')
        # Preserve oracle contracts when importing specialist media into the
        # general catalogue. A copied stream must never become a marked fixture.
        catalogue_path = out / 'fixtures/catalogue.json'
        if catalogue_path.is_file():
            catalogue = json.loads(catalogue_path.read_text())
            preserve_specialist_contracts(catalogue, specialist)
            catalogue_path.write_text(json.dumps(catalogue, indent=2) + '\n')
        specialist_parent = {'snapshot': str(parent), 'sha256': sha(source)}
    manifest = {'schema': 1, 'fixture_parent': fixture_parent, 'specialist_parent': specialist_parent, 'fixture': {'duration': args.duration, 'dimensions': [320,180], 'fps': 30},
                'git_revision': run(['git', 'rev-parse', 'HEAD']).strip(),
                'source_sha256': before, 'dirty_diff': run(['git', 'diff', '--', 'src', 'web']),
                'engines': engines, 'optionalArchiveSHA256': optional_archive_sha,
                'ffmpeg': run(['ffmpeg', '-version']).splitlines()[0],
                'setup_script_sha256': sha(Path(__file__)), 'expanded_generator_sha256': sha(preparation / 'expand.py') if args.expanded and not fixture_parent else None, 'assets_lock_sha256': sha(HERE / 'assets.lock.json'),
                'limits': ['Digital marked-output checks only, not physical output, exhaustive codec support or release qualification.',
                           'Missing local optional engines are recorded; older lab binaries are never substituted.'],
                'files': {str(p.relative_to(out)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                          for p in sorted(out.rglob('*')) if p.is_file()}}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'assets': str(out), 'files': len(manifest['files']), 'engines': engines}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='New directory, normally under build/head-to-head/')
    parser.add_argument('--lab', help='Optional preserved lab cache. Every reused dependency is hash-checked.')
    parser.add_argument('--fixtures-from', help='Reuse a completed snapshot’s exact hash-verified fixtures with newly built runtime assets')
    parser.add_argument('--specialist-from', help='Reuse a verified specialist catalogue whose bitstreams match --fixtures-from')
    parser.add_argument('--optional-archive', help='Use exact packaged optional ASS/adaptation assets and manifests')
    parser.add_argument('--expanded', action='store_true', help='Generate all planned catalogue fixtures or record preparation blockers')
    parser.add_argument('--duration', type=int, default=36)
    try:
        prepare(parser.parse_args())
    except (ValueError, FileExistsError) as error:
        raise SystemExit(str(error))
