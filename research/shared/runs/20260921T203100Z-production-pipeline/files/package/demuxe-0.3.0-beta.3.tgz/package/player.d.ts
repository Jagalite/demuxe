// SPDX-License-Identifier: GPL-3.0-or-later
export * from './web/generated/player/index.js';
