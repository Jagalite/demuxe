// SPDX-License-Identifier: GPL-3.0-or-later
import { bufferingPolicy, resolveBuffering, shakaBufferingOptions } from './buffering.js';
import { NativePlayer } from './native-player.js';
import { ShakaNetworkPolicy } from './shaka-network.js';
import { PlayerError } from './errors.js';
import { rasterizePreview } from '../preview/images.js';
import { plainVTT } from './plain-vtt.js';
const runtimes = new Map();
function runtimeAt(base, signal) {
    const aborted = () => new PlayerError('ABORTED', 'Shaka runtime loading cancelled');
    if (signal.aborted)
        return Promise.reject(aborted());
    const url = new URL('web/vendor/shaka-player.js', base);
    if (url.origin !== location.origin)
        return Promise.reject(new PlayerError('ASSET_LOAD_FAILED', 'Shaka runtime must be same-origin'));
    let shared = runtimes.get(url.href);
    if (!shared) {
        const controller = new AbortController();
        const entry = { promise: undefined, pending: true, users: 0, cancel: () => { } };
        entry.promise = new Promise((resolve, reject) => {
            let script, blob;
            const finish = (error) => {
                if (!entry.pending)
                    return;
                entry.pending = false;
                clearTimeout(timer);
                if (script) {
                    script.onload = null;
                    script.onerror = null;
                    script.remove();
                }
                if (blob)
                    URL.revokeObjectURL(blob);
                if (error) {
                    controller.abort();
                    if (runtimes.get(url.href) === entry)
                        runtimes.delete(url.href);
                    reject(error);
                }
                else
                    resolve(globalThis.shaka);
            };
            entry.cancel = () => finish(aborted());
            const timer = setTimeout(() => finish(new PlayerError('ASSET_LOAD_FAILED', 'Shaka runtime loading timed out')), 15000);
            // Removing a network script element does not reliably abort its download
            // or execution. Fetch is cancellable; the blob executes only while owned.
            void (async () => {
                const response = await fetch(url.href, { signal: controller.signal, credentials: 'same-origin', redirect: 'error' });
                if (!response.ok)
                    throw new Error('Shaka asset response failed');
                const code = await response.text();
                if (!entry.pending)
                    return;
                blob = URL.createObjectURL(new Blob(['if(document.currentScript?.isConnected){\n', code, '\n}'], { type: 'text/javascript' }));
                script = document.createElement('script');
                script.src = blob;
                script.async = true;
                script.onload = () => { const runtime = globalThis.shaka; finish(runtime?.Player ? undefined : new PlayerError('ASSET_LOAD_FAILED', 'Shaka runtime is unavailable')); };
                script.onerror = () => finish(new PlayerError('ASSET_LOAD_FAILED', 'Shaka runtime execution failed'));
                document.head.append(script);
            })().catch(() => finish(new PlayerError('ASSET_LOAD_FAILED', 'Shaka runtime loading failed')));
        });
        runtimes.set(url.href, entry);
        shared = entry;
    }
    const entry = shared;
    entry.users++;
    return new Promise((resolve, reject) => {
        let done = false;
        const release = () => { done = true; signal.removeEventListener('abort', cancel); if (--entry.users === 0 && entry.pending)
            entry.cancel(); };
        const cancel = () => { if (done)
            return; release(); reject(aborted()); };
        signal.addEventListener('abort', cancel, { once: true });
        entry.promise.then(runtime => { if (!done) {
            release();
            resolve(runtime);
        } }, error => { if (!done) {
            release();
            reject(error);
        } });
    });
}
/** Shaka exclusively owns adaptive manifests, scheduling, ABR and MediaSource.
 * NativePlayer supplies only media-element controls, output verification and gain. */
export class ShakaBackend extends EventTarget {
    video;
    assetBase;
    buffering;
    ready = Promise.resolve();
    properties = new Map();
    native;
    player;
    policy;
    runtime;
    stopped = false;
    runtimeLoad = new AbortController();
    opening = false;
    failure;
    disposal;
    listeners = [];
    blobs = new Set();
    external = new Map();
    visible = true;
    selectedSub = 'auto';
    audioDisabled = false;
    source;
    constructor(video, assetBase = new URL('../../../', import.meta.url), buffering = bufferingPolicy()) {
        super();
        this.video = video;
        this.assetBase = assetBase;
        this.buffering = buffering;
        this.native = new NativePlayer(video, 'never', assetBase);
        for (const type of ['mpv', 'activity', 'error', 'log']) {
            const listener = (event) => {
                if (this.stopped)
                    return;
                this.refresh();
                const detail = event.detail;
                if (type === 'mpv' && detail.event === 'property-change' && ['track-list', 'native-live', 'native-seekable', 'duration'].includes(detail.name))
                    detail.data = this.properties.get(detail.name);
                if (type === 'error' && this.opening)
                    return;
                this.emit(type, detail);
            };
            this.native.addEventListener(type, listener);
            this.listeners.push(() => this.native.removeEventListener(type, listener));
        }
        this.refresh();
    }
    /** Shaka owns image-track indexing. Return its authored reference without
     * downloading a sprite through playback's network/error/ABR machinery. */
    async previewFrame(request) {
        const player = this.player;
        if (!player || this.stopped)
            return null;
        request.signal.throwIfAborted();
        const indexStart = performance.now();
        // In pinned Shaka, clear DASH JPEG SegmentList/Template indexes are metadata
        // only: SegmentBase/index templates reject non-MP4/WebM at manifest admission.
        // HLS lazy playlists and other formats must already be indexed.
        const streams = player.getManifest()?.imageStreams ?? [];
        const eligible = streams.filter(stream => !stream.encrypted && (stream.segmentIndex ||
            (this.source?.format === 'dash' && !player.isDynamic() && stream.mimeType === 'image/jpeg')));
        const ids = new Set(eligible.map(stream => stream.id));
        const tracks = player.getImageTracks().filter(track => ids.has(track.id));
        if (!tracks.length)
            return null;
        const track = [...tracks].sort((a, b) => Math.abs((a.width ?? request.width) - request.width) - Math.abs((b.width ?? request.width) - request.width))[0];
        const stream = eligible.find(stream => stream.id === track.id);
        if (!stream.segmentIndex)
            await stream.createSegmentIndex();
        request.signal.throwIfAborted();
        const thumbnail = await player.getThumbnails(track.id, request.time);
        request.signal.throwIfAborted();
        if (!thumbnail || this.stopped || player !== this.player)
            return null;
        const indexLookupMs = performance.now() - indexStart;
        if (!this.runtime || !this.source || !this.policy)
            return null;
        const runtime = this.runtime, policy = this.policy.forkForPreview();
        const type = runtime.net.NetworkingEngine.RequestType.SEGMENT;
        const acquisitionStart = performance.now();
        try {
            for (const uri of thumbnail.uris) {
                request.signal.throwIfAborted();
                const networkRequest = runtime.net.NetworkingEngine.makeRequest([uri], { ...runtime.net.NetworkingEngine.defaultRetryParameters(), timeout: 5000, maxAttempts: 1 });
                if (thumbnail.startByte || thumbnail.endByte !== null)
                    networkRequest.headers.Range = `bytes=${thumbnail.startByte}-${thumbnail.endByte ?? ''}`;
                policy.filter(type, networkRequest);
                const operation = policy.plugin(uri, networkRequest, type, () => { }, () => { }, {});
                const cancel = () => { void operation.abort(); };
                request.signal.addEventListener('abort', cancel, { once: true });
                try {
                    const response = await operation.promise;
                    request.signal.throwIfAborted();
                    const bytes = new Uint8Array(response.data), byteAcquisitionMs = performance.now() - acquisitionStart, conversionStart = performance.now();
                    const image = await rasterizePreview(new Blob([bytes], { type: thumbnail.mimeType ?? 'image/jpeg' }), request, { x: thumbnail.positionX, y: thumbnail.positionY, width: thumbnail.width, height: thumbnail.height });
                    return { time: thumbnail.startTime, actualTime: thumbnail.startTime, width: image.width, height: image.height, path: 'shaka-image-track', timestampKind: 'interval', temporalAccuracy: 'approximate', fidelity: 'full', image: { blob: image.blob }, metrics: { indexLookupMs, byteAcquisitionMs, resizeConversionMs: performance.now() - conversionStart, bytesFetched: bytes.length, bytesRead: bytes.length } };
                }
                catch (error) {
                    request.signal.throwIfAborted();
                    if (uri === thumbnail.uris.at(-1))
                        throw error;
                }
                finally {
                    request.signal.removeEventListener('abort', cancel);
                }
            }
            return null;
        }
        finally {
            policy.destroy();
        }
    }
    emit(type, detail) { this.dispatchEvent(new CustomEvent(type, { detail })); }
    active() { if (this.stopped)
        throw new PlayerError('ABORTED', 'Player is destroyed'); }
    loaded() { this.active(); if (!this.player)
        throw new PlayerError('INVALID_ARGUMENT', 'No streaming source'); return this.player; }
    mapped(error) {
        if (this.policy?.terminalError)
            return this.policy.terminalError;
        if (error instanceof PlayerError)
            return error;
        const e = error;
        if (this.stopped)
            return new PlayerError('ABORTED', 'Player is destroyed');
        if (e.category === 1)
            return new Error(`Source transport: Shaka network failure (${e.code})`);
        if (e.category === 6)
            return new PlayerError('UNSUPPORTED_FEATURE', `Shaka DRM is not configured (${e.code})`);
        if ([2, 3, 4, 5].includes(e.category ?? 0))
            return new PlayerError('UNSUPPORTED_MEDIA', `Shaka cannot execute this stream (${e.code})`);
        return error instanceof Error ? error : new Error(`Shaka operation failed (${e.code ?? 'unknown'})`);
    }
    async open(_file) { throw new PlayerError('UNSUPPORTED_FEATURE', 'Shaka requires a remote HLS or DASH source'); }
    async openRemote(source) {
        this.active();
        if (this.player || this.opening)
            throw new PlayerError('INVALID_ARGUMENT', 'Shaka backend opens only one source');
        if (!['hls', 'dash'].includes(source.format ?? ''))
            throw new PlayerError('INVALID_ARGUMENT', 'Shaka requires HLS or DASH format');
        if (source.streaming?.maxBandwidth !== undefined && (!Number.isFinite(source.streaming.maxBandwidth) || source.streaming.maxBandwidth <= 0))
            throw new PlayerError('INVALID_ARGUMENT', 'maxBandwidth must be positive');
        this.source = source;
        this.opening = true;
        try {
            const runtime = this.runtime = await runtimeAt(this.assetBase, this.runtimeLoad.signal);
            this.active();
            runtime.polyfill.installAll();
            if (!runtime.Player.isBrowserSupported())
                throw new PlayerError('UNSUPPORTED_MEDIA', 'Shaka MSE is unsupported by this browser');
            const player = this.player = new runtime.Player();
            this.policy = new ShakaNetworkPolicy(source, runtime);
            const network = player.getNetworkingEngine();
            if (!network)
                throw new PlayerError('ASSET_LOAD_FAILED', 'Shaka networking engine is unavailable');
            network.registerRequestFilter(this.policy.filter);
            const changed = () => { if (!this.stopped) {
                this.refresh();
                this.emit('mpv', { event: 'property-change', name: 'track-list', data: this.properties.get('track-list') });
            } };
            for (const name of ['trackschanged', 'adaptation', 'variantchanged', 'textchanged', 'texttrackvisibility', 'streaming', 'loaded', 'buffering']) {
                player.addEventListener(name, changed);
                this.listeners.push(() => player.removeEventListener(name, changed));
            }
            const failed = (event) => { const detail = event.detail; if (detail.severity !== runtime.util.Error.Severity.CRITICAL)
                return; const error = this.failure = this.mapped(detail); if (!this.opening && !this.stopped)
                this.emit('error', error); };
            player.addEventListener('error', failed);
            this.listeners.push(() => player.removeEventListener('error', failed));
            player.configure({ streaming: { preferNativeHls: false, preferNativeDash: false, useNativeHlsForFairPlay: false }, abr: { enabled: !source.streaming?.representation }, restrictions: { maxBandwidth: source.streaming?.maxBandwidth ?? Infinity } });
            player.configure({ streaming: shakaBufferingOptions(this.buffering) });
            await player.attach(this.video);
            this.active();
            await player.load(source.url, undefined, source.format === 'hls' ? 'application/x-mpegurl' : 'application/dash+xml');
            this.active();
            if (this.failure)
                throw this.failure;
            if (player.getLoadMode() !== runtime.Player.LoadMode.MEDIA_SOURCE)
                throw new PlayerError('UNSUPPORTED_MEDIA', 'Shaka did not create an MSE presentation');
            if (player.isDynamic() && source.streaming?.live !== true)
                throw new PlayerError('SOURCE_PERMISSION', 'Live streaming requires explicit live permission');
            const representation = source.streaming?.representation;
            if (representation) {
                const variants = player.getVariantTracks(), active = variants.find(t => t.active);
                const audioKey = (t) => JSON.stringify([t.audioLanguage ?? t.language, t.originalLanguage, t.label, t.audioRoles, t.channelsCount, t.audioCodec, t.spatialAudio, t.accessibilityPurpose]);
                const token = /^variant:(\d+)$/.exec(representation);
                const matches = variants.filter(t => token ? String(t.id) === token[1] : t.originalVideoId === representation || (!t.videoCodec && t.originalAudioId === representation)).filter(t => !active || audioKey(t) === audioKey(active));
                if (matches.length !== 1)
                    throw new PlayerError('UNSUPPORTED_FEATURE', 'Cannot preserve requested streaming representation and selected audio unambiguously');
                player.selectVariantTrack(matches[0], true);
            }
            this.applyText();
            this.refresh();
            this.emit('mpv', { event: 'file-loaded' });
        }
        catch (error) {
            throw this.mapped(error);
        }
        finally {
            this.opening = false;
        }
    }
    refresh() {
        for (const [key, value] of this.native.properties)
            this.properties.set(key, value);
        const player = this.player;
        if (!player || this.stopped)
            return;
        this.properties.set('paused-for-cache', player.isBuffering?.() ?? false);
        const variants = player.getVariantTracks(), current = variants.find(t => t.active), texts = player.getTextTracks(), audio = this.audioTracks();
        const tracks = audio.map(({ track: t, id }) => ({ id, type: 'audio', codec: t.codecs, title: t.label, lang: t.language, selected: t.active && !this.audioDisabled }));
        tracks.push(...texts.map(t => ({ id: `shaka-sub-${t.id}`, type: 'sub', codec: t.codecs || t.mimeType, title: t.label, lang: t.language, selected: t.active && this.visible && this.selectedSub !== 'no', external: this.external.has(t.id), ...(this.external.has(t.id) ? { 'external-index': this.external.get(t.id) } : {}) })));
        if (current?.videoCodec)
            tracks.push({ id: `shaka-video-${current.videoId}`, type: 'video', codec: current.videoCodec, selected: true, 'demux-w': current.width, 'demux-h': current.height });
        this.properties.set('track-list', tracks);
        this.properties.set('native-live', player.isDynamic());
        const range = player.seekRange();
        this.properties.set('native-seekable', range.end > range.start ? [{ start: range.start, end: range.end }] : []);
        if (player.isDynamic())
            this.properties.set('duration', null);
    }
    audioTracks() {
        const tracks = this.player?.getAudioTracks() ?? [];
        // Channels, rate and codecs can be discovered only after selection. They
        // are descriptive metadata, never a stable public track identity.
        const key = (t) => `shaka-audio-${encodeURIComponent(JSON.stringify([t.language, t.originalLanguage, t.label, t.roles, t.spatialAudio, t.accessibilityPurpose]))}`;
        return tracks.map((track, index) => { const base = key(track), ambiguous = tracks.filter(t => key(t) === base).length > 1; return { track, id: ambiguous ? `${base}:ambiguous:${index}` : base, ambiguous }; });
    }
    expected() { const selected = this.player?.getVariantTracks().find(t => t.active); return { video: !!selected?.videoCodec, audio: !!selected?.audioCodec && !this.audioDisabled }; }
    async verifyStartup(_expected, output = false) { this.active(); if (this.failure)
        throw this.failure; await this.native.verifyStartup(this.expected(), output); this.active(); if (this.failure)
        throw this.failure; }
    verifyOutput() { return this.verifyStartup(undefined, true); }
    startupEvidence() { return { ...this.native.diagnostics.capability, sourceBufferCreated: !!this.player && this.player.getLoadMode() === this.runtime?.Player.LoadMode.MEDIA_SOURCE }; }
    async play() { this.active(); if (this.buffering.preload !== 'auto')
        this.player?.configure({ streaming: { bufferingGoal: 10, ...shakaBufferingOptions(this.buffering, false) } }); await this.native.play(); }
    async pause() { this.active(); await this.native.pause(); }
    async seek(seconds) { const range = this.loaded().seekRange(); if (!Number.isFinite(seconds) || seconds < range.start - .01 || seconds > range.end + .01)
        throw new PlayerError('INVALID_ARGUMENT', 'Seek target is outside the streaming seekable window'); await this.native.seek(Math.max(range.start, Math.min(range.end, seconds))); }
    async rate(value) { this.active(); await this.native.rate(value); }
    async volume(value) { this.active(); await this.native.volume(value); }
    async gain(value) { this.active(); await this.native.gain(value); }
    async selectTrack(type, id) {
        const player = this.loaded();
        if (type === 'audio') {
            if (id === 'no') {
                this.audioDisabled = true;
                this.video.muted = true;
            }
            else {
                const audio = this.audioTracks();
                const candidates = id === 'auto' ? audio.filter(t => t.track.active) : audio.filter(t => t.id === id);
                if (!audio.length && id === 'auto') {
                    this.refresh();
                    return;
                }
                if (candidates.length !== 1 || (id !== 'auto' && candidates[0].ambiguous))
                    throw new PlayerError('UNSUPPORTED_FEATURE', 'Cannot preserve requested audio track');
                const requested = candidates[0].track, representation = this.source?.streaming?.representation;
                if (representation) {
                    const token = /^variant:(\d+)$/.exec(representation);
                    const key = (language, originalLanguage, label, roles, spatial, purpose) => JSON.stringify([language ?? '', originalLanguage ?? '', label ?? '', roles ?? [], !!spatial, purpose ?? null]);
                    const expected = key(requested.language, requested.originalLanguage, requested.label, requested.roles, requested.spatialAudio, requested.accessibilityPurpose);
                    const matches = player.getVariantTracks().filter(t => (token ? String(t.id) === token[1] : t.originalVideoId === representation || (!t.videoCodec && t.originalAudioId === representation)) && t.bandwidth <= (this.source?.streaming?.maxBandwidth ?? Infinity)).filter(t => key(t.audioLanguage ?? t.language, t.originalLanguage, t.label, t.audioRoles, t.spatialAudio, t.accessibilityPurpose) === expected &&
                        (!t.channelsCount || !requested.channelsCount || t.channelsCount === requested.channelsCount) && (!t.audioCodec || !requested.codecs || t.audioCodec === requested.codecs));
                    if (matches.length !== 1)
                        throw new PlayerError('UNSUPPORTED_FEATURE', 'Cannot preserve pinned streaming representation and bandwidth with requested audio track');
                    player.selectVariantTrack(matches[0], true);
                    if (player.getVariantTracks().find(t => t.active)?.id !== matches[0].id)
                        throw new PlayerError('UNSUPPORTED_FEATURE', 'Shaka did not apply the pinned audio/video variant');
                }
                else
                    player.selectAudioTrack(requested);
                this.audioDisabled = false;
                this.video.muted = false;
            }
        }
        else {
            if (id === 'no') {
                this.selectedSub = id;
                this.applyText();
            }
            else {
                const texts = player.getTextTracks();
                const track = id === 'auto' ? texts.find(t => t.active) ?? texts[0] : texts.find(t => `shaka-sub-${t.id}` === id);
                if (!track && id !== 'auto')
                    throw new PlayerError('UNSUPPORTED_FEATURE', 'Cannot preserve requested subtitle track');
                if (track)
                    player.selectTextTrack(track);
                this.selectedSub = id;
                this.applyText();
            }
        }
        this.refresh();
        this.emit('mpv', { event: 'property-change', name: 'track-list', data: this.properties.get('track-list') });
    }
    applyText() { const player = this.player; if (!player)
        return; if (!this.visible || this.selectedSub === 'no') {
        player.selectTextTrack(null);
        return;
    } const texts = player.getTextTracks(); const selected = this.selectedSub === 'auto' ? texts.find(t => t.active) ?? texts[0] : texts.find(t => `shaka-sub-${t.id}` === this.selectedSub); if (selected)
        player.selectTextTrack(selected); }
    async subtitleVisible(visible) { this.active(); this.visible = visible; this.applyText(); this.refresh(); }
    async addTextTrack(track) { const player = this.loaded(); this.policy.authorize(track.src); const added = await player.addTextTrackAsync(track.src, track.language ?? 'und', 'subtitle', 'text/vtt', undefined, track.label); this.active(); this.external.set(added.id, this.external.size + 1); if (track.default) {
        player.selectTextTrack(added);
        this.selectedSub = `shaka-sub-${added.id}`;
    } this.applyText(); this.refresh(); }
    async addSubtitle(asset) {
        if (!plainVTT(asset))
            throw new PlayerError('UNSUPPORTED_FEATURE', 'Shaka external subtitles require plain WebVTT');
        const url = URL.createObjectURL(new Blob([asset.bytes], { type: 'text/vtt' }));
        this.blobs.add(url);
        this.policy?.ownBlob(url);
        await this.addTextTrack({ src: url, label: asset.label, language: asset.language, default: asset.select });
    }
    resize(width, height) { this.native.resize(width, height); }
    audioDiagnostics() { return { ...this.native.audioDiagnostics(), source: 'shaka-mse' }; }
    get diagnostics() { const native = this.native.diagnostics; return { ...native, buffering: { ...resolveBuffering(this.buffering, 'shaka'), settings: this.player?.getConfiguration?.().streaming ? { bufferingGoal: this.player.getConfiguration().streaming.bufferingGoal, rebufferingGoal: this.player.getConfiguration().streaming.rebufferingGoal, bufferBehind: this.player.getConfiguration().streaming.bufferBehind } : shakaBufferingOptions(this.buffering) }, path: 'shaka-mse', plan: 'shaka-mse', packaging: 'shaka', streaming: { engine: 'shaka', version: this.runtime?.Player.version, format: this.source?.format, live: this.player?.isDynamic() ?? false, seekRange: this.player?.seekRange(), abr: !this.source?.streaming?.representation, maxBandwidth: this.source?.streaming?.maxBandwidth, variants: this.player?.getVariantTracks().map(t => ({ id: `variant:${t.id}`, representation: t.originalVideoId ?? t.originalAudioId, active: t.active, bandwidth: t.bandwidth, width: t.width, height: t.height, audioCodec: t.audioCodec, videoCodec: t.videoCodec })), network: this.policy?.diagnostics }, capability: this.startupEvidence() }; }
    destroy() { return this.disposal ?? (this.disposal = this.dispose()); }
    async dispose() { this.stopped = true; this.runtimeLoad.abort(); this.listeners.splice(0).forEach(remove => remove()); this.policy?.destroy(); try {
        await this.player?.destroy();
    }
    finally {
        this.player = undefined;
        await this.native.destroy();
        for (const url of this.blobs)
            URL.revokeObjectURL(url);
        this.blobs.clear();
        this.external.clear();
        this.source = undefined;
    } }
}
